package com.example.flavorbalance

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.ComponentActivity

class CreditActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_credit)

        // Recupera el nombre del usuario de la actividad MainActivity
        val userName = intent.getStringExtra("USER_NAME") ?: "Usuario"

        // Mostrar el texto con el nombre del usuario
        val creditTextView: TextView = findViewById(R.id.credit_text)
        creditTextView.text = "$userName, estás usando la v0.1 de la aplicación."

        // Descripción de la aplicación
        val appDescription: TextView = findViewById(R.id.app_description)
        appDescription.text = "Esta aplicación es un repositorio de recetas donde los usuarios pueden compartir, guardar y comentar recetas."

        // Configurar el botón de contacto
        val contactButton: Button = findViewById(R.id.contact_button)
        contactButton.setOnClickListener {
            sendEmail()
        }
    }

    // Función para enviar el correo electrónico
    private fun sendEmail() {
        val intent = Intent(Intent.ACTION_SEND)
        intent.type = "message/rfc822"
        intent.putExtra(Intent.EXTRA_EMAIL, arrayOf("tu_correo@dominio.com"))
        intent.putExtra(Intent.EXTRA_SUBJECT, "Consulta de la app FlavorBalance")
        intent.putExtra(Intent.EXTRA_TEXT, "¡Hola! Quisiera hacer una consulta sobre la app FlavorBalance.")

        // Verificar que hay una aplicación que pueda manejar el intent
        try {
            startActivity(Intent.createChooser(intent, "Selecciona tu aplicación de correo"))
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
