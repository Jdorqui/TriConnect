package com.example.flavorbalance

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.activity.ComponentActivity

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val navigateButton: Button = findViewById(R.id.navigate_button)
        val userNameEditText: EditText = findViewById(R.id.username_edit_text)

        navigateButton.setOnClickListener {
            val userName = userNameEditText.text.toString()

            // Crear un Intent para navegar a CreditActivity
            val intent = Intent(this, CreditActivity::class.java)
            intent.putExtra("USER_NAME", userName)
            startActivity(intent)
        }
    }
}
