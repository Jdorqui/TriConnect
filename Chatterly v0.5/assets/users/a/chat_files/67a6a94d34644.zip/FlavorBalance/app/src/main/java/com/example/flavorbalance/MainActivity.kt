package com.example.flavorbalance

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.core.content.ContextCompat
import androidx.viewpager2.widget.ViewPager2

class MainActivity : ComponentActivity() {

    private lateinit var handler: Handler
    private lateinit var runnable: Runnable
    private lateinit var dotsLayout: LinearLayout
    private lateinit var dots: ArrayList<ImageView>
    private val imageList = listOf(
        R.drawable.carrusel_png1,
        R.drawable.carrusel_png2,
        R.drawable.carrusel_png3
    )
    // Lista de textos que cambian con cada imagen
    private val textList = listOf(
        R.string.carrusel_text1,
        R.string.carrusel_text2,
        R.string.carrusel_text3
    )
    // Lista de subtextos
    private val subTextList = listOf(
        R.string.carrusel_text1_1,
        R.string.carrusel_text2_1,
        R.string.carrusel_text3_1
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Inicializamos el ViewPager2
        val viewPager: ViewPager2 = findViewById(R.id.viewPager)
        val imageSliderAdapter = ImageSliderAdapter(imageList)
        viewPager.adapter = imageSliderAdapter

        // Puntos debajo del carrusel
        dotsLayout = findViewById(R.id.dotsLayout)
        dots = ArrayList()
        for (i in imageList.indices) {
            val dot = ImageView(this)
            dot.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.circle_unselected))
            val params = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            params.setMargins(8, 0, 8, 0)
            dot.layoutParams = params
            dotsLayout.addView(dot)
            dots.add(dot)
        }

        // Configuración del cambio automático de imágenes cada 3 segundos
        handler = Handler(mainLooper)
        runnable = Runnable {
            val currentItem = viewPager.currentItem
            val nextItem = if (currentItem == imageList.size - 1) 0 else currentItem + 1
            viewPager.setCurrentItem(nextItem, true)
            handler.postDelayed(runnable, 5000) // Llamar nuevamente después de 5 segundos
        }
        handler.postDelayed(runnable, 5000) // Iniciar el cambio automático al inicio

        // Cambiar el color del punto seleccionado
        viewPager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                super.onPageSelected(position)
                updateDots(position)

                // Actualizar el texto
                val descriptionText: TextView = findViewById(R.id.imageDescription)
                val subDescriptionText: TextView = findViewById(R.id.imageSubDescription)

                descriptionText.setText(textList[position]) // Cambiar el texto
                subDescriptionText.setText(subTextList[position]) // Cambiar el subtexto
            }
        })

        // Configuración del botón de navegación
        val navigateButton: Button = findViewById(R.id.navigate_button)
        val userNameEditText: EditText = findViewById(R.id.username_edit_text)

        navigateButton.setOnClickListener {
            val userName = userNameEditText.text.toString()

            // Crear un Intent para navegar a CreditActivity
            val intent = Intent(this, CreditActivity::class.java)
            intent.putExtra("USER_NAME", userName)
            startActivity(intent)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacks(runnable) // Eliminar los callbacks al destruir la actividad
    }

    private fun updateDots(position: Int) {
        for (i in dots.indices) {
            if (i == position) {
                dots[i].setImageDrawable(ContextCompat.getDrawable(this, R.drawable.circle_selected))
            } else {
                dots[i].setImageDrawable(ContextCompat.getDrawable(this, R.drawable.circle_unselected))
            }
        }
    }
}